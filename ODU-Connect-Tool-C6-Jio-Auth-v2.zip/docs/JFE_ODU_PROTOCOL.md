# JioHomeJFE 1.0.53 — ODU BLE findings

Source analyzed: user-provided `JioHomeJFE_1.0.53_APKPure.xapk`, base APK `com.jio.home.jfe.apk`.

## Verified UUID mapping

| UUID | Role established from bytecode |
|---|---|
| `0000ca7a-0000-1000-a435-311b63657f1f` | ODU service UUID used by `ESimBluetoothLeService.z(List)` and manual-service discovery |
| `0000ca77-0000-1000-a435-311b63657f1f` | ODU characteristic obtained from the ODU service (`Lyf/e$a.a()`) |
| `0000ca78-0000-1000-a435-311b63657f1f` | ODU characteristic obtained from the ODU service (`Lyf/e$a.b()`) |
| `0000ca7b-0000-1000-a435-311b63657f1f` | ODU characteristic obtained from the ODU service (`Lyf/e$a.c()`) |
| `00002902-0000-1000-8000-00805f9b34fb` | Standard Client Characteristic Configuration Descriptor; compared in the notification setup path |
| `0000ca79-0000-1000-a435-311b63657f1f` | Present as a UUID constant in the APK, but no assignment to the analyzed `ESimBluetoothLeService` characteristic fields was established |

## ODU BLE behavior established

- `ESimBluetoothLeService` uses Android `BluetoothGatt`, `BluetoothGattService`, and `BluetoothGattCharacteristic`.
- `onServicesDiscovered` enumerates services and characteristics.
- The ODU service is matched against CA7A.
- CA77, CA78 and CA7B are obtained from that service.
- The service enables characteristic notifications through `setCharacteristicNotification()` and writes the standard 0x2902 descriptor.
- `onCharacteristicRead` obtains the characteristic value and decodes it as UTF-8. The APK contains the log string `JODIMP uuid read ip=>`, showing an ODU read path that reports an IP value.
- ODU firmware identifiers observed in the APK include `JODU52540`, `JODU52540_REL_25_01_05_S`, and `JODU52540_REL_25_01_11_S`.
- The APK contains explicit `readPanIPCharacteristic`, `readPairCharacteristic`, `writeResetBT`, and reset-Bluetooth paths.

## Firmware-update conclusion

The APK contains `ESimFirmwareUpgrade` and firmware-version APIs, but the explicit image/signature upload/update implementation found in the APK is associated with IDU local APIs (`IduLocalApis`, image/signature upload, admin login, etc.). The analyzed ODU BLE service did not yield a verified ODU image-transfer/chunk/commit protocol.

Therefore this project intentionally does **not** send guessed firmware-update packets. A real ODU updater should only be added after the ODU firmware-transfer protocol is independently verified on an authorized test device or from additional vendor documentation/telemetry.

## C6 scope

This project is specifically for the user's Mimosa C6/Jio ODU context. No C6X-specific UUIDs or firmware assumptions are used.
