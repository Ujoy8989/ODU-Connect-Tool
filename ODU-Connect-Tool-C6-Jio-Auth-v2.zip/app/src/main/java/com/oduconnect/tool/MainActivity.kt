package com.oduconnect.tool

import android.Manifest
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64
import java.util.UUID

class MainActivity : android.app.Activity() {
    private var scanner: BluetoothLeScanner? = null
    private var scanning = false
    private var gatt: BluetoothGatt? = null
    private lateinit var log: TextView
    private lateinit var deviceList: LinearLayout
    private val devices = linkedMapOf<String, BluetoothDevice>()
    private val chars = linkedMapOf<String, BluetoothGattCharacteristic>()

    companion object {
        // Verified from JioHomeJFE 1.0.53 bytecode/static analysis.
        // CA7A is used as the ODU service UUID.
        val ODU_SERVICE = UUID.fromString("0000ca7a-0000-1000-a435-311b63657f1f")
        val ODU_CHAR_CA77 = UUID.fromString("0000ca77-0000-1000-a435-311b63657f1f")
        val ODU_CHAR_CA78 = UUID.fromString("0000ca78-0000-1000-a435-311b63657f1f")
        val ODU_CHAR_CA79 = UUID.fromString("0000ca79-0000-1000-a435-311b63657f1f")
        val ODU_CHAR_CA7B = UUID.fromString("0000ca7b-0000-1000-a435-311b63657f1f")
        val CLIENT_CONFIG = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply {
            text = "Mimosa C6 / Jio ODU Tool"
            textSize = 22f
        })
        root.addView(TextView(this).apply {
            text = "ODU-only • verified JioHomeJFE BLE map"
            setPadding(0, 8, 0, 12)
        })

        val host = EditText(this).apply {
            hint = "ODU IP / hostname (e.g. 192.168.1.20)"
            singleLine = true
        }
        val port = EditText(this).apply {
            hint = "Port (default 443)"
            setText("443")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            singleLine = true
        }
        val user = EditText(this).apply {
            hint = "ODU username"
            singleLine = true
        }
        val pass = EditText(this).apply {
            hint = "ODU password"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            singleLine = true
        }
        root.addView(host)
        root.addView(port)
        root.addView(user)
        root.addView(pass)

        val login = Button(this).apply {
            text = "TEST ODU LOGIN / API"
            setOnClickListener { testHttp(host.text.toString().trim(), port.text.toString().trim(), user.text.toString(), pass.text.toString()) }
        }
        root.addView(login)

        val scan = Button(this).apply {
            text = "SCAN ODU BLE"
            setOnClickListener { startScan() }
        }
        root.addView(scan)

        val firmware = Button(this).apply {
            text = "FIRMWARE — PROTOCOL NOT VERIFIED"
            setOnClickListener { firmwareNotice() }
        }
        root.addView(firmware)

        root.addView(TextView(this).apply {
            text = "CA7A service • CA77 / CA78 / CA7B characteristics • CA79 observed but not assigned by the analyzed service path"
            textSize = 12f
            setPadding(0, 8, 0, 8)
        })

        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(deviceList) }, LinearLayout.LayoutParams(-1, 180))

        log = TextView(this).apply { textSize = 12f }
        root.addView(ScrollView(this).apply { addView(log) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun requestBlePermissions() {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) p += Manifest.permission.BLUETOOTH_SCAN
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) p += Manifest.permission.BLUETOOTH_CONNECT
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            p += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (p.isNotEmpty()) requestPermissions(p.toTypedArray(), 10)
    }

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private fun startScan() {
        val a = adapter() ?: return log("Bluetooth unavailable")
        if (!a.isEnabled) {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            return
        }
        if (scanning) return
        devices.clear()
        deviceList.removeAllViews()
        scanner = a.bluetoothLeScanner ?: return log("BLE scanner unavailable")
        scanning = true
        log("Scanning…")
        scanner!!.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCallback)
        window.decorView.postDelayed({ stopScan() }, 12000)
    }

    private fun stopScan() {
        if (!scanning) return
        scanner?.stopScan(scanCallback)
        scanning = false
        log("Scan complete: ${devices.size} device(s)")
        devices.values.forEach { addDeviceButton(it) }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            devices[d.address] = d
            val uuids = result.scanRecord?.serviceUuids?.map { it.uuid } ?: emptyList()
            if (uuids.any { it == ODU_SERVICE || it == ODU_CHAR_CA77 || it == ODU_CHAR_CA78 || it == ODU_CHAR_CA79 || it == ODU_CHAR_CA7B }) {
                log("★ ODU candidate ${safeName(d)} ${d.address} RSSI=${result.rssi} UUIDs=$uuids")
            }
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            log("BLE scan failed: $errorCode")
        }
    }

    private fun addDeviceButton(d: BluetoothDevice) {
        val b = Button(this).apply {
            text = "${safeName(d)}\n${d.address}"
            setOnClickListener { connect(d) }
        }
        deviceList.addView(b)
    }

    private fun connect(device: BluetoothDevice) {
        log("Connecting ${safeName(device)} ${device.address}")
        gatt?.close()
        gatt = device.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            log("GATT state=$newState status=$status")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Connected", Toast.LENGTH_SHORT).show() }
                g.discoverServices()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            log("Services discovered=${g.services.size} status=$status")
            chars.clear()
            g.services.forEach { s ->
                val isOdu = s.uuid == ODU_SERVICE
                log("SERVICE ${s.uuid}${if (isOdu) "  [VERIFIED ODU SERVICE]" else ""}")
                s.characteristics.forEach { c ->
                    val known = c.uuid == ODU_CHAR_CA77 || c.uuid == ODU_CHAR_CA78 || c.uuid == ODU_CHAR_CA79 || c.uuid == ODU_CHAR_CA7B
                    log("  CHAR ${c.uuid} props=${c.properties}${if (known) " [ODU]" else ""}")
                    if (isOdu && known) chars[c.uuid.toString()] = c
                }
            }
            // Read-only probing: only characteristics explicitly marked READ are touched.
            chars.values.filter { it.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0 }.forEach {
                g.readCharacteristic(it)
            }
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            val raw = c.value ?: ByteArray(0)
            val utf8 = raw.toString(Charsets.UTF_8).replace("\u0000", "")
            log("READ ${c.uuid} status=$status bytes=${raw.hex()} utf8=${utf8.take(160)}")
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            log("NOTIFY ${c.uuid} bytes=${value.hex()} utf8=${value.toString(Charsets.UTF_8).replace("\u0000", "").take(160)}")
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            log("WRITE ${c.uuid} status=$status")
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            log("DESCRIPTOR ${d.uuid} write status=$status")
        }
    }

    private fun testHttp(host: String, port: String, user: String, pass: String) {
        if (host.isBlank()) return log("Enter ODU IP/hostname first")
        val p = port.toIntOrNull() ?: return log("Invalid port")
        Thread {
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://$host:$p/")
                log("HTTPS probe $url")
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 5000
                    readTimeout = 5000
                    useCaches = false
                    if (user.isNotEmpty()) {
                        val token = Base64.getEncoder().encodeToString("$user:$pass".toByteArray(Charsets.UTF_8))
                        setRequestProperty("Authorization", "Basic $token")
                    }
                }
                val code = conn.responseCode
                log("HTTP status=$code server=${conn.getHeaderField("Server") ?: "-"}")
                val stream = if (code >= 400) conn.errorStream else conn.inputStream
                val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                log("BODY ${body.take(1000)}")
            } catch (e: Exception) {
                log("HTTPS error: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                conn?.disconnect()
            }
        }.start()
    }

    private fun firmwareNotice() {
        AlertDialog.Builder(this)
            .setTitle("ODU firmware update")
            .setMessage("JioHomeJFE 1.0.53 contains ODU firmware/version data and a verified BLE transport, but the analyzed firmware-transfer/commit protocol for the ODU was not established. Its explicit image/signature upload flow is tied to IDU local APIs. This app therefore refuses to send guessed firmware commands.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun safeName(d: BluetoothDevice): String = try { d.name ?: "Unknown ODU" } catch (_: SecurityException) { "Bluetooth device" }
    private fun log(s: String) { runOnUiThread { log.append("\n$s") } }
    private fun ByteArray.hex() = joinToString("") { "%02X".format(it) }
}
