# ODU Connect Tool

Authorized Mimosa C6 / Jio ODU diagnostic client.

## Current features
- Credential-based local HTTPS diagnostic probe.
- User-entered ODU host, port, username and password.
- Existing verified JioHomeJFE BLE service/characteristic discovery.
- Read-only BLE characteristic probing where the characteristic advertises READ.
- Diagnostic logging.

## Firmware
Firmware transfer is intentionally disabled until the Mimosa C6/Jio ODU firmware-transfer protocol is independently verified. The app does not guess or send destructive firmware commands.

## Build
Open the repository in GitHub and run **Actions → Build Android APK → Run workflow**. The workflow produces `app-debug.apk` as an artifact.
